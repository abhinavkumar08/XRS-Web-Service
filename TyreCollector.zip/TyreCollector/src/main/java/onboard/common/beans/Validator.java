package onboard.common.beans;

public interface Validator<T> {
	
	
	public boolean isValid(T t);
		

	
}
