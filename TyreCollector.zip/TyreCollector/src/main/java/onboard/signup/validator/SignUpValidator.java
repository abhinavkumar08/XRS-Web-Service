package onboard.signup.validator;

import onboard.common.beans.Validator;
import onboard.signup.beans.Seller;

public class SignUpValidator implements Validator<Seller> {

	public boolean isValid(Seller seller) {

		// to do : input validation .

		return true;
	}

}
