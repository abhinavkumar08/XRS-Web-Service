package onboard.signin.constants;

public class SignInConstants {
	
	public static final String AUTHORIZED = "authorized";
	
	public static final String UNAUTHORIZED = "unauthorized";
	
	public static final String PASSWORD = "password";

}
