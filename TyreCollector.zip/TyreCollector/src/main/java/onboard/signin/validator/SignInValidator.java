package onboard.signin.validator;

import onboard.common.beans.Validator;
import onboard.signin.beans.UserCredential;

public class SignInValidator implements Validator<UserCredential> {

	public boolean isValid(UserCredential credential) {

		// to do : input validation .

		return true;
	}

}
